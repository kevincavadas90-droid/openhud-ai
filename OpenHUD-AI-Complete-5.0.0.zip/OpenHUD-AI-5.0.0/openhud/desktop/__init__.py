"""OpenHUD Desktop package."""
